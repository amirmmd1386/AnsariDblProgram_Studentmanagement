﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'database3DataSet.tbl_stu' table. You can move, or remove it, as needed.
            this.tbl_stuTableAdapter.Fill(this.database3DataSet.tbl_stu);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            tbl_stuTableAdapter.InsertQuery(txtname.Text, txtfam.Text, int.Parse(txtnum.Text), int.Parse(txtscore.Text));
            tbl_stuTableAdapter.Fill(this.database3DataSet.tbl_stu);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int row = e.RowIndex;
            txtid.Text = Convert.ToString(dataGridView1[0, row].Value);
            txtname.Text = Convert.ToString(dataGridView1[1, row].Value);
            txtfam.Text = Convert.ToString(dataGridView1[2, row].Value);
            txtscore.Text = Convert.ToString(dataGridView1[4, row].Value);
            txtnum.Text = Convert.ToString(dataGridView1[3, row].Value);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tbl_stuTableAdapter.DeleteQuery(int.Parse(txtid.Text));
            tbl_stuTableAdapter.Fill(this.database3DataSet.tbl_stu);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            tbl_stuTableAdapter.UpdateQuery(txtname.Text,
                txtfam.Text, int.Parse(txtnum.Text), int.Parse(txtscore.Text), int.Parse(txtid.Text));
            tbl_stuTableAdapter.Fill(this.database3DataSet.tbl_stu);
        }

        private void txtname_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
